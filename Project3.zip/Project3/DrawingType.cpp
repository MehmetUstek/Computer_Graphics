enum class DrawingType {
	SOLID,
	WIREFRAME,
	SHADING,
	TEXTURE
};