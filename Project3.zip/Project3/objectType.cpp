enum class ObjectType {
	CUBE,
	SPHERE,
	BUNNY
};